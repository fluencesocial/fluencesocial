"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define types for content items
export type ContentItem = {
  id: string;
  title: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
};

// Define types for scheduled posts
export type ScheduledPost = {
  id: string;
  contentId: string;
  platforms: ('twitter' | 'facebook' | 'instagram' | 'linkedin')[];
  scheduledDate: Date;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  content: ContentItem;
};

// Define types for content library context
export type ContentLibraryData = {
  contentItems: ContentItem[];
  scheduledPosts: ScheduledPost[];
  addContentItem: (item: Omit<ContentItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateContentItem: (id: string, data: Partial<ContentItem>) => void;
  removeContentItem: (id: string) => void;
  schedulePost: (post: Omit<ScheduledPost, 'id'>) => void;
  updateScheduledPost: (id: string, data: Partial<ScheduledPost>) => void;
  removeScheduledPost: (id: string) => void;
};

// Create context with default values
const ContentLibraryContext = createContext<ContentLibraryData>({
  contentItems: [],
  scheduledPosts: [],
  addContentItem: () => {},
  updateContentItem: () => {},
  removeContentItem: () => {},
  schedulePost: () => {},
  updateScheduledPost: () => {},
  removeScheduledPost: () => {},
});

// Provider component
export function ContentLibraryProvider({ children }: { children: ReactNode }) {
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([]);

  // Load initial data
  useEffect(() => {
    // In a real app, you would fetch this data from your API
    // For now, we'll use mock data
    const mockContentItems: ContentItem[] = [
      {
        id: '1',
        title: 'New Product Announcement',
        content: 'We are excited to announce our new product line launching next week!',
        mediaUrl: 'https://example.com/product-image.jpg',
        mediaType: 'image',
        tags: ['product', 'announcement', 'marketing'],
        createdAt: new Date('2025-03-15'),
        updatedAt: new Date('2025-03-15'),
      },
      {
        id: '2',
        title: 'Customer Testimonial',
        content: 'Hear what our customers are saying about our services!',
        mediaUrl: 'https://example.com/testimonial-video.mp4',
        mediaType: 'video',
        tags: ['testimonial', 'customer', 'feedback'],
        createdAt: new Date('2025-03-20'),
        updatedAt: new Date('2025-03-20'),
      },
    ];

    const mockScheduledPosts: ScheduledPost[] = [
      {
        id: '1',
        contentId: '1',
        platforms: ['twitter', 'facebook'],
        scheduledDate: new Date('2025-04-04T10:00:00'),
        status: 'scheduled',
        content: mockContentItems[0],
      },
      {
        id: '2',
        contentId: '2',
        platforms: ['instagram', 'linkedin'],
        scheduledDate: new Date('2025-04-07T14:30:00'),
        status: 'draft',
        content: mockContentItems[1],
      },
    ];

    setContentItems(mockContentItems);
    setScheduledPosts(mockScheduledPosts);
  }, []);

  // Add a new content item
  const addContentItem = (item: Omit<ContentItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: ContentItem = {
      ...item,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setContentItems((prev) => [...prev, newItem]);
  };

  // Update a content item
  const updateContentItem = (id: string, data: Partial<ContentItem>) => {
    setContentItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, ...data, updatedAt: new Date() } : item
      )
    );
  };

  // Remove a content item
  const removeContentItem = (id: string) => {
    setContentItems((prev) => prev.filter((item) => item.id !== id));
    // Also remove any scheduled posts using this content
    setScheduledPosts((prev) => prev.filter((post) => post.contentId !== id));
  };

  // Schedule a post
  const schedulePost = (post: Omit<ScheduledPost, 'id'>) => {
    const newPost: ScheduledPost = {
      ...post,
      id: Date.now().toString(),
    };
    setScheduledPosts((prev) => [...prev, newPost]);
  };

  // Update a scheduled post
  const updateScheduledPost = (id: string, data: Partial<ScheduledPost>) => {
    setScheduledPosts((prev) =>
      prev.map((post) =>
        post.id === id ? { ...post, ...data } : post
      )
    );
  };

  // Remove a scheduled post
  const removeScheduledPost = (id: string) => {
    setScheduledPosts((prev) => prev.filter((post) => post.id !== id));
  };

  return (
    <ContentLibraryContext.Provider
      value={{
        contentItems,
        scheduledPosts,
        addContentItem,
        updateContentItem,
        removeContentItem,
        schedulePost,
        updateScheduledPost,
        removeScheduledPost,
      }}
    >
      {children}
    </ContentLibraryContext.Provider>
  );
}

// Custom hook to use the content library context
export function useContentLibrary() {
  const context = useContext(ContentLibraryContext);
  if (context === undefined) {
    throw new Error('useContentLibrary must be used within a ContentLibraryProvider');
  }
  return context;
}
