export function formatDate(input: string | number): string {
  const date = new Date(input)
  return date.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat().format(num)
}

export function cn(...inputs: any[]): string {
  return inputs.filter(Boolean).join(" ")
}
