"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define types for analytics data
export type AnalyticsData = {
  followers: {
    total: number;
    growth: number;
    growthPercentage: number;
    byPlatform: {
      platform: string;
      count: number;
      growth: number;
    }[];
  };
  engagement: {
    rate: number;
    change: number;
    byPlatform: {
      platform: string;
      rate: number;
      change: number;
    }[];
  };
  impressions: {
    total: number;
    change: number;
    changePercentage: number;
    byPlatform: {
      platform: string;
      count: number;
      change: number;
    }[];
  };
  topPosts: {
    id: string;
    platform: string;
    content: string;
    engagement: number;
    impressions: number;
    publishedAt: Date;
  }[];
  demographics: {
    ageGroups: {
      range: string;
      percentage: number;
    }[];
    gender: {
      type: string;
      percentage: number;
    }[];
    locations: {
      country: string;
      percentage: number;
    }[];
  };
};

// Define types for analytics context
export type AnalyticsContextType = {
  data: AnalyticsData | null;
  loading: boolean;
  error: string | null;
  timeRange: 'week' | 'month' | 'quarter' | 'year';
  setTimeRange: (range: 'week' | 'month' | 'quarter' | 'year') => void;
  refreshData: () => void;
};

// Create context with default values
const AnalyticsContext = createContext<AnalyticsContextType>({
  data: null,
  loading: false,
  error: null,
  timeRange: 'month',
  setTimeRange: () => {},
  refreshData: () => {},
});

// Provider component
export function AnalyticsProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'quarter' | 'year'>('month');

  // Load analytics data
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // In a real app, you would fetch this data from your API based on the timeRange
      // For now, we'll use mock data
      const mockData: AnalyticsData = {
        followers: {
          total: 12345,
          growth: 245,
          growthPercentage: 2.5,
          byPlatform: [
            { platform: 'twitter', count: 5432, growth: 120 },
            { platform: 'instagram', count: 4321, growth: 85 },
            { platform: 'facebook', count: 1876, growth: 32 },
            { platform: 'linkedin', count: 716, growth: 8 },
          ],
        },
        engagement: {
          rate: 3.2,
          change: -0.5,
          byPlatform: [
            { platform: 'twitter', rate: 2.8, change: -0.3 },
            { platform: 'instagram', rate: 4.7, change: 0.2 },
            { platform: 'facebook', rate: 2.1, change: -0.7 },
            { platform: 'linkedin', rate: 3.5, change: -0.1 },
          ],
        },
        impressions: {
          total: 245678,
          change: 30710,
          changePercentage: 12.5,
          byPlatform: [
            { platform: 'twitter', count: 98765, change: 12345 },
            { platform: 'instagram', count: 87654, change: 9876 },
            { platform: 'facebook', count: 43210, change: 5432 },
            { platform: 'linkedin', count: 16049, change: 3057 },
          ],
        },
        topPosts: [
          {
            id: '1',
            platform: 'instagram',
            content: 'Check out our new product line launching next week!',
            engagement: 1234,
            impressions: 5678,
            publishedAt: new Date('2025-03-15'),
          },
          {
            id: '2',
            platform: 'twitter',
            content: "We're excited to announce our partnership with @bigcompany",
            engagement: 987,
            impressions: 4321,
            publishedAt: new Date('2025-03-20'),
          },
          {
            id: '3',
            platform: 'facebook',
            content: 'Our annual customer appreciation event is coming up!',
            engagement: 765,
            impressions: 3456,
            publishedAt: new Date('2025-03-25'),
          },
          {
            id: '4',
            platform: 'linkedin',
            content: "We're hiring! Check out our open positions.",
            engagement: 543,
            impressions: 2345,
            publishedAt: new Date('2025-03-28'),
          },
        ],
        demographics: {
          ageGroups: [
            { range: '18-24', percentage: 35 },
            { range: '25-34', percentage: 42 },
            { range: '35-44', percentage: 15 },
            { range: '45-54', percentage: 5 },
            { range: '55+', percentage: 3 },
          ],
          gender: [
            { type: 'Female', percentage: 58 },
            { type: 'Male', percentage: 40 },
            { type: 'Other', percentage: 2 },
          ],
          locations: [
            { country: 'United States', percentage: 65 },
            { country: 'United Kingdom', percentage: 12 },
            { country: 'Canada', percentage: 8 },
            { country: 'Australia', percentage: 6 },
            { country: 'Other', percentage: 9 },
          ],
        },
      };
      
      // Simulate API delay
      setTimeout(() => {
        setData(mockData);
        setLoading(false);
      }, 500);
    } catch (err) {
      setError('Failed to fetch analytics data');
      setLoading(false);
    }
  };

  // Fetch data when component mounts or timeRange changes
  useEffect(() => {
    fetchData();
  }, [timeRange]);

  // Refresh data manually
  const refreshData = () => {
    fetchData();
  };

  return (
    <AnalyticsContext.Provider
      value={{
        data,
        loading,
        error,
        timeRange,
        setTimeRange,
        refreshData,
      }}
    >
      {children}
    </AnalyticsContext.Provider>
  );
}

// Custom hook to use the analytics context
export function useAnalytics() {
  const context = useContext(AnalyticsContext);
  if (context === undefined) {
    throw new Error('useAnalytics must be used within an AnalyticsProvider');
  }
  return context;
}
