"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useSession } from 'next-auth/react';

// Define types for social media accounts
export type SocialAccount = {
  id: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin';
  username: string;
  profileUrl: string;
  profileImage: string;
  connected: boolean;
  accessToken?: string;
};

// Define types for user data
export type UserData = {
  socialAccounts: SocialAccount[];
  addSocialAccount: (account: SocialAccount) => void;
  removeSocialAccount: (id: string) => void;
  updateSocialAccount: (id: string, data: Partial<SocialAccount>) => void;
};

// Create context with default values
const UserContext = createContext<UserData>({
  socialAccounts: [],
  addSocialAccount: () => {},
  removeSocialAccount: () => {},
  updateSocialAccount: () => {},
});

// Provider component
export function UserProvider({ children }: { children: ReactNode }) {
  const { data: session } = useSession();
  const [socialAccounts, setSocialAccounts] = useState<SocialAccount[]>([]);

  // Load user data when session changes
  useEffect(() => {
    if (session?.user) {
      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      setSocialAccounts([
        {
          id: '1',
          platform: 'twitter',
          username: 'acmeinc',
          profileUrl: 'https://twitter.com/acmeinc',
          profileImage: 'https://randomuser.me/api/portraits/men/1.jpg',
          connected: true,
        },
        {
          id: '2',
          platform: 'instagram',
          username: 'acmeinc',
          profileUrl: 'https://instagram.com/acmeinc',
          profileImage: 'https://randomuser.me/api/portraits/men/1.jpg',
          connected: true,
        },
      ]);
    }
  }, [session]);

  // Add a new social account
  const addSocialAccount = (account: SocialAccount) => {
    setSocialAccounts((prev) => [...prev, account]);
  };

  // Remove a social account
  const removeSocialAccount = (id: string) => {
    setSocialAccounts((prev) => prev.filter((account) => account.id !== id));
  };

  // Update a social account
  const updateSocialAccount = (id: string, data: Partial<SocialAccount>) => {
    setSocialAccounts((prev) =>
      prev.map((account) =>
        account.id === id ? { ...account, ...data } : account
      )
    );
  };

  return (
    <UserContext.Provider
      value={{
        socialAccounts,
        addSocialAccount,
        removeSocialAccount,
        updateSocialAccount,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

// Custom hook to use the user context
export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
