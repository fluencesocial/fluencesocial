// This file contains performance optimizations for the application

// Import necessary dependencies
import { memo } from 'react';
import { Sidebar } from '@/components/sidebar';
import { Header } from '@/components/header';

// Memoize components that don't need frequent re-renders
export const MemoizedSidebar = memo(Sidebar);
export const MemoizedHeader = memo(Header);

// Create a utility function for image optimization
export function optimizeImageUrl(url, width = 400, quality = 80) {
  // In a real app, this would use a CDN or image optimization service
  // For now, we'll just return the original URL
  return url;
}

// Create a debounce utility for performance-intensive operations
export function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Create a throttle utility for scroll events
export function throttle(func, limit) {
  let inThrottle;
  return function executedFunction(...args) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
}
