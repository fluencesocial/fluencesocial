"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define types for messages
export type Message = {
  id: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin';
  type: 'comment' | 'mention' | 'direct' | 'review';
  content: string;
  sender: {
    id: string;
    name: string;
    username: string;
    profileImage: string;
  };
  timestamp: Date;
  isRead: boolean;
  isFlagged: boolean;
};

// Define types for inbox context
export type InboxData = {
  messages: Message[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  toggleFlag: (id: string) => void;
  deleteMessage: (id: string) => void;
  filterMessages: (filters: {
    platforms?: string[];
    types?: string[];
    read?: boolean;
    flagged?: boolean;
  }) => Message[];
};

// Create context with default values
const InboxContext = createContext<InboxData>({
  messages: [],
  unreadCount: 0,
  markAsRead: () => {},
  markAllAsRead: () => {},
  toggleFlag: () => {},
  deleteMessage: () => {},
  filterMessages: () => [],
});

// Provider component
export function InboxProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  // Load initial data
  useEffect(() => {
    // In a real app, you would fetch this data from your API
    // For now, we'll use mock data
    const mockMessages: Message[] = [
      {
        id: '1',
        platform: 'twitter',
        type: 'mention',
        content: 'Hey @acmeinc, love your products! When will the new line be available?',
        sender: {
          id: 'user1',
          name: 'Jane Smith',
          username: 'janesmith',
          profileImage: 'https://randomuser.me/api/portraits/women/12.jpg',
        },
        timestamp: new Date('2025-04-01T04:30:00'),
        isRead: false,
        isFlagged: false,
      },
      {
        id: '2',
        platform: 'instagram',
        type: 'comment',
        content: 'Your latest post is amazing! Can you share more details about this product?',
        sender: {
          id: 'user2',
          name: 'Robert Johnson',
          username: 'robertj',
          profileImage: 'https://randomuser.me/api/portraits/men/15.jpg',
        },
        timestamp: new Date('2025-03-31T18:45:00'),
        isRead: false,
        isFlagged: true,
      },
      {
        id: '3',
        platform: 'facebook',
        type: 'direct',
        content: 'I have a question about your return policy. Can you help me?',
        sender: {
          id: 'user3',
          name: 'Emily Davis',
          username: 'emilyd',
          profileImage: 'https://randomuser.me/api/portraits/women/22.jpg',
        },
        timestamp: new Date('2025-03-31T14:20:00'),
        isRead: true,
        isFlagged: false,
      },
      {
        id: '4',
        platform: 'linkedin',
        type: 'comment',
        content: 'Great article about industry trends! Would love to connect and discuss further.',
        sender: {
          id: 'user4',
          name: 'Michael Wilson',
          username: 'michaelw',
          profileImage: 'https://randomuser.me/api/portraits/men/32.jpg',
        },
        timestamp: new Date('2025-03-30T09:15:00'),
        isRead: false,
        isFlagged: false,
      },
      {
        id: '5',
        platform: 'twitter',
        type: 'direct',
        content: "I'm interested in partnering with your company. Who should I contact?",
        sender: {
          id: 'user5',
          name: 'Sarah Brown',
          username: 'sarahb',
          profileImage: 'https://randomuser.me/api/portraits/women/33.jpg',
        },
        timestamp: new Date('2025-03-29T16:50:00'),
        isRead: true,
        isFlagged: false,
      },
    ];

    setMessages(mockMessages);
    setUnreadCount(mockMessages.filter(msg => !msg.isRead).length);
  }, []);

  // Mark a message as read
  const markAsRead = (id: string) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === id ? { ...msg, isRead: true } : msg
      )
    );
    updateUnreadCount();
  };

  // Mark all messages as read
  const markAllAsRead = () => {
    setMessages(prev => 
      prev.map(msg => ({ ...msg, isRead: true }))
    );
    setUnreadCount(0);
  };

  // Toggle flag status
  const toggleFlag = (id: string) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === id ? { ...msg, isFlagged: !msg.isFlagged } : msg
      )
    );
  };

  // Delete a message
  const deleteMessage = (id: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== id));
    updateUnreadCount();
  };

  // Filter messages based on criteria
  const filterMessages = (filters: {
    platforms?: string[];
    types?: string[];
    read?: boolean;
    flagged?: boolean;
  }) => {
    return messages.filter(msg => {
      if (filters.platforms && filters.platforms.length > 0 && !filters.platforms.includes(msg.platform)) {
        return false;
      }
      if (filters.types && filters.types.length > 0 && !filters.types.includes(msg.type)) {
        return false;
      }
      if (filters.read !== undefined && msg.isRead !== filters.read) {
        return false;
      }
      if (filters.flagged !== undefined && msg.isFlagged !== filters.flagged) {
        return false;
      }
      return true;
    });
  };

  // Update unread count
  const updateUnreadCount = () => {
    setUnreadCount(messages.filter(msg => !msg.isRead).length);
  };

  return (
    <InboxContext.Provider
      value={{
        messages,
        unreadCount,
        markAsRead,
        markAllAsRead,
        toggleFlag,
        deleteMessage,
        filterMessages,
      }}
    >
      {children}
    </InboxContext.Provider>
  );
}

// Custom hook to use the inbox context
export function useInbox() {
  const context = useContext(InboxContext);
  if (context === undefined) {
    throw new Error('useInbox must be used within an InboxProvider');
  }
  return context;
}
