import React from 'react';

// Create a configuration file for deployment settings
const config = {
  // Application name and version
  appName: 'Social Media Manager',
  version: '1.0.0',
  
  // API endpoints
  apiEndpoints: {
    twitter: {
      profile: '/api/twitter/profile',
      tweets: '/api/twitter/tweets',
      search: '/api/twitter/search'
    },
    linkedin: {
      profile: '/api/linkedin/profile',
      search: '/api/linkedin/search'
    }
  },
  
  // Feature flags for production
  features: {
    analytics: true,
    smartInbox: true,
    contentLibrary: true,
    scheduling: true,
    multiAccountSupport: true,
    facebookIntegration: false, // Not yet implemented
    instagramIntegration: false // Not yet implemented
  },
  
  // Performance settings
  performance: {
    enableMemoization: true,
    enableLazyLoading: true,
    imageCacheTime: 86400, // 24 hours in seconds
    apiCacheTime: 300, // 5 minutes in seconds
    maxConcurrentRequests: 5
  },
  
  // SEO settings
  seo: {
    title: 'Social Media Manager - Streamline Your Social Media Workflow',
    description: 'A modern social media management platform for businesses and agencies. Connect, schedule, analyze, and grow your social presence.',
    keywords: 'social media, management, analytics, scheduling, marketing'
  }
};

export default config;
