import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import Analytics from '@/app/(dashboard)/analytics/page';
import { useAnalyticsData } from '@/hooks/use-analytics-data';

// Mock the custom hook
vi.mock('@/hooks/use-analytics-data', () => ({
  useAnalyticsData: vi.fn()
}));

describe('Analytics Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders loading state correctly', () => {
    // Mock the hook to return loading state
    useAnalyticsData.mockReturnValue({
      loading: true,
      error: null,
      data: null,
      timeRange: 'month'
    });

    render(<Analytics />);
    
    expect(screen.getByText('Loading analytics data...')).toBeInTheDocument();
  });

  it('renders error state correctly', () => {
    // Mock the hook to return error state
    useAnalyticsData.mockReturnValue({
      loading: false,
      error: 'Failed to load analytics data',
      data: null,
      timeRange: 'month'
    });

    render(<Analytics />);
    
    expect(screen.getByText('Error Loading Data')).toBeInTheDocument();
    expect(screen.getByText('Failed to load analytics data')).toBeInTheDocument();
  });

  it('renders no data state correctly', () => {
    // Mock the hook to return no data state
    useAnalyticsData.mockReturnValue({
      loading: false,
      error: null,
      data: null,
      timeRange: 'month'
    });

    render(<Analytics />);
    
    expect(screen.getByText('No Data Available')).toBeInTheDocument();
    expect(screen.getByText('Connect your social media accounts to view analytics.')).toBeInTheDocument();
  });

  it('renders analytics content correctly', () => {
    // Mock the hook to return successful data
    useAnalyticsData.mockReturnValue({
      loading: false,
      error: null,
      timeRange: 'month',
      data: {
        followers: {
          total: 12345,
          growth: 245,
          growthPercentage: 2.5,
          byPlatform: [
            { platform: 'twitter', count: 5432, growth: 120 },
            { platform: 'instagram', count: 4321, growth: 85 },
            { platform: 'facebook', count: 1876, growth: 32 },
            { platform: 'linkedin', count: 716, growth: 8 }
          ]
        },
        engagement: {
          rate: 3.8,
          change: 0.6,
          byPlatform: [
            { platform: 'twitter', rate: 2.8, change: -0.3 },
            { platform: 'instagram', rate: 4.7, change: 0.2 },
            { platform: 'facebook', rate: 2.1, change: -0.7 },
            { platform: 'linkedin', rate: 3.5, change: -0.1 }
          ]
        },
        impressions: {
          total: 245678,
          change: 30710,
          changePercentage: 12.5,
          byPlatform: [
            { platform: 'twitter', count: 98765, change: 12345 },
            { platform: 'instagram', count: 87654, change: 9876 },
            { platform: 'facebook', count: 43210, change: 5432 },
            { platform: 'linkedin', count: 16049, change: 3057 }
          ]
        },
        topPosts: [
          {
            id: '1',
            platform: 'instagram',
            content: 'Check out our new product line launching next week!',
            engagement: 1234,
            impressions: 5678,
            publishedAt: new Date('2025-03-15')
          }
        ],
        demographics: {
          ageGroups: [
            { range: '18-24', percentage: 35 },
            { range: '25-34', percentage: 42 },
            { range: '35-44', percentage: 15 }
          ],
          gender: [
            { type: 'Female', percentage: 58 },
            { type: 'Male', percentage: 40 },
            { type: 'Other', percentage: 2 }
          ],
          locations: [
            { country: 'United States', percentage: 65 },
            { country: 'United Kingdom', percentage: 12 },
            { country: 'Canada', percentage: 8 }
          ]
        }
      }
    });

    render(<Analytics />);
    
    // Check for main analytics elements
    expect(screen.getByText('Analytics')).toBeInTheDocument();
    expect(screen.getByText('Total Impressions')).toBeInTheDocument();
    expect(screen.getByText('245,678')).toBeInTheDocument();
    expect(screen.getByText('Engagement Rate')).toBeInTheDocument();
    expect(screen.getByText('3.8%')).toBeInTheDocument();
    expect(screen.getByText('Follower Growth')).toBeInTheDocument();
    expect(screen.getByText('+245')).toBeInTheDocument();
    
    // Check for platform performance
    expect(screen.getByText('Performance by Platform')).toBeInTheDocument();
    expect(screen.getByText('twitter')).toBeInTheDocument();
    expect(screen.getByText('instagram')).toBeInTheDocument();
    
    // Check for demographics
    expect(screen.getByText('Audience Demographics')).toBeInTheDocument();
    expect(screen.getByText('Age Groups')).toBeInTheDocument();
    expect(screen.getByText('18-24')).toBeInTheDocument();
    expect(screen.getByText('Gender')).toBeInTheDocument();
    expect(screen.getByText('Female')).toBeInTheDocument();
  });
});
