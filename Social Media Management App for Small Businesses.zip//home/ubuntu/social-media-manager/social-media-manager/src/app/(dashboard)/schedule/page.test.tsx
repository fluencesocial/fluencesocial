import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { useContentLibrary } from '@/lib/content-library-context';
import Schedule from '@/app/(dashboard)/schedule/page';

// Mock the custom hook
vi.mock('@/lib/content-library-context', () => ({
  useContentLibrary: vi.fn()
}));

describe('Schedule Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders schedule with posts correctly', () => {
    // Mock the hook to return scheduled posts
    useContentLibrary.mockReturnValue({
      contentItems: [],
      scheduledPosts: [
        {
          id: '1',
          contentId: '1',
          platforms: ['twitter', 'facebook'],
          scheduledDate: new Date('2025-04-04T10:00:00'),
          status: 'scheduled',
          content: {
            id: '1',
            title: 'New Product Announcement',
            content: 'We are excited to announce our new product line!',
            tags: ['product', 'announcement'],
            createdAt: new Date('2025-03-15'),
            updatedAt: new Date('2025-03-15'),
          }
        },
        {
          id: '2',
          contentId: '2',
          platforms: ['instagram', 'linkedin'],
          scheduledDate: new Date('2025-04-07T14:30:00'),
          status: 'draft',
          content: {
            id: '2',
            title: 'Customer Testimonial',
            content: 'Hear what our customers are saying!',
            tags: ['testimonial', 'customer'],
            createdAt: new Date('2025-03-20'),
            updatedAt: new Date('2025-03-20'),
          }
        }
      ],
      addContentItem: vi.fn(),
      updateContentItem: vi.fn(),
      removeContentItem: vi.fn(),
      schedulePost: vi.fn(),
      updateScheduledPost: vi.fn(),
      removeScheduledPost: vi.fn(),
    });

    render(<Schedule />);
    
    // Check for main schedule elements
    expect(screen.getByText('Posting Schedule')).toBeInTheDocument();
    expect(screen.getByText('Calendar View')).toBeInTheDocument();
    expect(screen.getByText('List View')).toBeInTheDocument();
    expect(screen.getByText('Create New Post')).toBeInTheDocument();
    
    // Check for calendar elements
    expect(screen.getByText('April 2025')).toBeInTheDocument();
    expect(screen.getByText('Sun')).toBeInTheDocument();
    expect(screen.getByText('Mon')).toBeInTheDocument();
    
    // Check for upcoming posts section
    expect(screen.getByText('Upcoming Posts')).toBeInTheDocument();
  });
});
