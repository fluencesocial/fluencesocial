import { requireAuth } from "@/lib/session";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // This will redirect to sign in if not authenticated
  await requireAuth();

  return (
    <div className="flex min-h-screen">
      {/* Sidebar and main content will be rendered by the child layout */}
      {children}
    </div>
  );
}
