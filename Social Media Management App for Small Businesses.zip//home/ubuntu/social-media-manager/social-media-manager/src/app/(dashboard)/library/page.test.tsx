import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import Library from '@/app/(dashboard)/library/page';
import { useContentLibrary } from '@/lib/content-library-context';

// Mock the custom hook
vi.mock('@/lib/content-library-context', () => ({
  useContentLibrary: vi.fn()
}));

describe('Library Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders content library with items correctly', () => {
    // Mock the hook to return content items
    useContentLibrary.mockReturnValue({
      contentItems: [
        {
          id: '1',
          title: 'New Product Announcement',
          content: 'We are excited to announce our new product line launching next week!',
          mediaUrl: 'https://example.com/product-image.jpg',
          mediaType: 'image',
          tags: ['product', 'announcement', 'marketing'],
          createdAt: new Date('2025-03-15'),
          updatedAt: new Date('2025-03-15'),
        },
        {
          id: '2',
          title: 'Customer Testimonial',
          content: 'Hear what our customers are saying about our services!',
          mediaUrl: 'https://example.com/testimonial-video.mp4',
          mediaType: 'video',
          tags: ['testimonial', 'customer', 'feedback'],
          createdAt: new Date('2025-03-20'),
          updatedAt: new Date('2025-03-20'),
        }
      ],
      scheduledPosts: [],
      addContentItem: vi.fn(),
      updateContentItem: vi.fn(),
      removeContentItem: vi.fn(),
      schedulePost: vi.fn(),
      updateScheduledPost: vi.fn(),
      removeScheduledPost: vi.fn(),
    });

    render(<Library />);
    
    // Check for main library elements
    expect(screen.getByText('Content Library')).toBeInTheDocument();
    expect(screen.getByText('Upload Content')).toBeInTheDocument();
    
    // Check for filter options
    expect(screen.getByText('Categories')).toBeInTheDocument();
    expect(screen.getByText('Images')).toBeInTheDocument();
    expect(screen.getByText('Videos')).toBeInTheDocument();
    
    // Check for tags section
    expect(screen.getByText('Tags')).toBeInTheDocument();
    expect(screen.getByText('Marketing')).toBeInTheDocument();
    expect(screen.getByText('Product')).toBeInTheDocument();
  });

  it('renders empty library state correctly', () => {
    // Mock the hook to return empty content items
    useContentLibrary.mockReturnValue({
      contentItems: [],
      scheduledPosts: [],
      addContentItem: vi.fn(),
      updateContentItem: vi.fn(),
      removeContentItem: vi.fn(),
      schedulePost: vi.fn(),
      updateScheduledPost: vi.fn(),
      removeScheduledPost: vi.fn(),
    });

    render(<Library />);
    
    // Check for main library elements
    expect(screen.getByText('Content Library')).toBeInTheDocument();
    expect(screen.getByText('Upload Content')).toBeInTheDocument();
    
    // Check for filter options
    expect(screen.getByText('Categories')).toBeInTheDocument();
  });
});
