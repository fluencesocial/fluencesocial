import React from "react";
import { Button } from "@/components/ui/button";

export default function Settings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <Button>Save Changes</Button>
      </div>
      
      <div className="grid gap-6 md:grid-cols-12">
        <div className="md:col-span-3">
          <nav className="flex flex-col space-y-1">
            <a href="#account" className="rounded-lg bg-gray-100 px-3 py-2 text-sm font-medium">
              Account Settings
            </a>
            <a href="#team" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-gray-100">
              Team Members
            </a>
            <a href="#connections" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-gray-100">
              Social Connections
            </a>
            <a href="#notifications" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-gray-100">
              Notifications
            </a>
            <a href="#billing" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-gray-100">
              Billing & Plans
            </a>
            <a href="#api" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-gray-100">
              API Access
            </a>
          </nav>
        </div>
        
        <div className="md:col-span-9 space-y-6">
          <div id="account" className="rounded-lg border bg-white p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-4">Account Settings</h3>
            <div className="space-y-4">
              <div className="flex flex-col space-y-1.5">
                <label htmlFor="name" className="text-sm font-medium">Name</label>
                <input
                  id="name"
                  className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  defaultValue="John Doe"
                />
              </div>
              <div className="flex flex-col space-y-1.5">
                <label htmlFor="email" className="text-sm font-medium">Email</label>
                <input
                  id="email"
                  type="email"
                  className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  defaultValue="john.doe@example.com"
                />
              </div>
              <div className="flex flex-col space-y-1.5">
                <label htmlFor="company" className="text-sm font-medium">Company</label>
                <input
                  id="company"
                  className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  defaultValue="Acme Inc."
                />
              </div>
              <div className="flex flex-col space-y-1.5">
                <label htmlFor="timezone" className="text-sm font-medium">Timezone</label>
                <select
                  id="timezone"
                  className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>Pacific Time (UTC-08:00)</option>
                  <option>Mountain Time (UTC-07:00)</option>
                  <option>Central Time (UTC-06:00)</option>
                  <option selected>Eastern Time (UTC-05:00)</option>
                  <option>Greenwich Mean Time (UTC+00:00)</option>
                  <option>Central European Time (UTC+01:00)</option>
                </select>
              </div>
              <div className="pt-2">
                <Button variant="outline">Change Password</Button>
              </div>
            </div>
          </div>
          
          <div id="team" className="rounded-lg border bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Team Members</h3>
              <Button variant="outline" size="sm">Invite Member</Button>
            </div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between border-b pb-4">
                  <div className="flex items-center space-x-4">
                    <span className="relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full">
                      <img
                        className="aspect-square h-full w-full"
                        src={`https://randomuser.me/api/portraits/${i % 2 === 0 ? 'women' : 'men'}/${i + 10}.jpg`}
                        alt="Avatar"
                      />
                    </span>
                    <div>
                      <p className="font-medium">{i === 1 ? "John Doe (You)" : i === 2 ? "Jane Smith" : "Robert Johnson"}</p>
                      <p className="text-sm text-gray-500">{i === 1 ? "john.doe@example.com" : i === 2 ? "jane.smith@example.com" : "robert.johnson@example.com"}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                      {i === 1 ? "Admin" : "Editor"}
                    </span>
                    {i !== 1 && (
                      <Button variant="outline" size="sm">Manage</Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div id="connections" className="rounded-lg border bg-white p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-4">Social Connections</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-blue-100 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-blue-500">
                      <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Twitter</p>
                    <p className="text-sm text-gray-500">Connected as @acmeinc</p>
                  </div>
                </div>
                <div>
                  <Button variant="outline" size="sm">Disconnect</Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-pink-100 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-pink-500">
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Instagram</p>
                    <p className="text-sm text-gray-500">Connected as @acmeinc</p>
                  </div>
                </div>
                <div>
                  <Button variant="outline" size="sm">Disconnect</Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-blue-100 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-blue-700">
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Facebook</p>
                    <p className="text-sm text-gray-500">Not connected</p>
                  </div>
                </div>
                <div>
                  <Button size="sm">Connect</Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between pb-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-blue-100 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-blue-800">
                      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                      <rect x="2" y="9" width="4" height="12" />
                      <circle cx="4" cy="4" r="2" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">LinkedIn</p>
                    <p className="text-sm text-gray-500">Not connected</p>
                  </div>
                </div>
                <div>
                  <Button size="sm">Connect</Button>
                </div>
              </div>
            </div>
          </div>
          
          <div id="notifications" className="rounded-lg border bg-white p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-4">Notification Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-gray-500">Receive email notifications for important events</p>
                </div>
                <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                  <span className="absolute h-4 w-4 rounded-full bg-white left-1 transition-transform duration-200 transform translate-x-5"></span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Push Notifications</p>
                  <p className="text-sm text-gray-500">Receive push notifications for important events</p>
                </div>
                <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-blue-600">
                  <span className="absolute h-4 w-4 rounded-full bg-white left-1 transition-transform duration-200 transform translate-x-5"></span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">SMS Notifications</p>
                  <p className="text-sm text-gray-500">Receive SMS notifications for critical alerts</p>
                </div>
                <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                  <span className="absolute h-4 w-4 rounded-full bg-white left-1 transition-transform duration-200 transform"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
