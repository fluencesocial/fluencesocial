import React from "react";
import { Button } from "@/components/ui/button";

export default function Schedule() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Posting Schedule</h1>
        <div className="flex space-x-2">
          <Button variant="outline">Calendar View</Button>
          <Button variant="outline">List View</Button>
          <Button>Create New Post</Button>
        </div>
      </div>
      
      <div className="rounded-lg border bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex space-x-1">
            <Button variant="outline" size="sm">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </Button>
            <Button variant="outline" size="sm">April 2025</Button>
            <Button variant="outline" size="sm">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </Button>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">Today</Button>
            <Button variant="outline" size="sm">Week</Button>
            <Button variant="outline" size="sm">Month</Button>
          </div>
        </div>
        
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="bg-white p-2 text-center text-sm font-medium">
              {day}
            </div>
          ))}
          
          {Array.from({ length: 35 }).map((_, i) => {
            const day = i - 2; // Offset to start month on correct day
            const isCurrentMonth = day >= 0 && day < 30;
            const isToday = day === 0;
            const hasEvents = [3, 7, 12, 15, 21, 25, 28].includes(day);
            
            return (
              <div 
                key={i} 
                className={`bg-white p-2 min-h-[100px] ${isCurrentMonth ? "" : "text-gray-400"} ${isToday ? "bg-blue-50 border border-blue-200" : ""}`}
              >
                <div className="flex justify-between items-start">
                  <span className={`text-sm font-medium ${isToday ? "text-blue-600" : ""}`}>
                    {isCurrentMonth ? day + 1 : day < 0 ? 31 + day : day - 29}
                  </span>
                  {hasEvents && (
                    <span className="flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                  )}
                </div>
                
                {hasEvents && isCurrentMonth && (
                  <div className="mt-2 space-y-1">
                    {day === 3 && (
                      <div className="rounded bg-blue-100 p-1 text-xs text-blue-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-blue-500">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                          </svg>
                          10:00 AM
                        </div>
                      </div>
                    )}
                    {day === 7 && (
                      <div className="rounded bg-pink-100 p-1 text-xs text-pink-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-pink-500">
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                          </svg>
                          2:30 PM
                        </div>
                      </div>
                    )}
                    {day === 12 && (
                      <div className="rounded bg-blue-100 p-1 text-xs text-blue-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-blue-700">
                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                          </svg>
                          9:00 AM
                        </div>
                      </div>
                    )}
                    {day === 15 && (
                      <div className="rounded bg-blue-100 p-1 text-xs text-blue-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-blue-800">
                            <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                            <rect x="2" y="9" width="4" height="12" />
                            <circle cx="4" cy="4" r="2" />
                          </svg>
                          4:00 PM
                        </div>
                      </div>
                    )}
                    {day === 21 && (
                      <div className="rounded bg-pink-100 p-1 text-xs text-pink-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-pink-500">
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                          </svg>
                          11:30 AM
                        </div>
                      </div>
                    )}
                    {day === 25 && (
                      <div className="rounded bg-blue-100 p-1 text-xs text-blue-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-blue-500">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                          </svg>
                          3:15 PM
                        </div>
                      </div>
                    )}
                    {day === 28 && (
                      <div className="rounded bg-blue-100 p-1 text-xs text-blue-700 truncate">
                        <div className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1 text-blue-700">
                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                          </svg>
                          1:00 PM
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="rounded-lg border bg-white p-6 shadow-sm">
        <h3 className="text-lg font-medium mb-4">Upcoming Posts</h3>
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center justify-between border-b pb-4">
              <div className="flex items-center space-x-4">
                <div className="h-16 w-16 rounded bg-gray-100 flex items-center justify-center">
                  <span className="text-gray-500 text-xs">Image</span>
                </div>
                <div>
                  <p className="font-medium">New Product Announcement</p>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <span className="flex items-center mr-3">
                      {i % 3 === 0 ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-blue-500">
                          <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                        </svg>
                      ) : i % 2 === 0 ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-pink-500">
                          <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-blue-700">
                          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                        </svg>
                      )}
                      {i === 1 ? "Apr 4, 10:00 AM" : i === 2 ? "Apr 7, 2:30 PM" : i === 3 ? "Apr 12, 9:00 AM" : i === 4 ? "Apr 15, 4:00 PM" : "Apr 21, 11:30 AM"}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      i === 1 ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"
                    }`}>
                      {i === 1 ? "Scheduled" : "Draft"}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">Edit</Button>
                <Button variant="outline" size="sm">Duplicate</Button>
                <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">Delete</Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
