import React from "react";
import { Button } from "@/components/ui/button";

export default function Library() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Content Library</h1>
        <div className="flex space-x-2">
          <Button variant="outline">Filter</Button>
          <Button variant="outline">Sort</Button>
          <Button>Upload Content</Button>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-12">
        <div className="md:col-span-3 space-y-4">
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Categories</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="images" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="images" className="ml-2 text-sm text-gray-700">Images</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="videos" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="videos" className="ml-2 text-sm text-gray-700">Videos</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="articles" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="articles" className="ml-2 text-sm text-gray-700">Articles</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="templates" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="templates" className="ml-2 text-sm text-gray-700">Templates</label>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Tags</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="marketing" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="marketing" className="ml-2 text-sm text-gray-700">Marketing</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="product" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="product" className="ml-2 text-sm text-gray-700">Product</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="branding" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="branding" className="ml-2 text-sm text-gray-700">Branding</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="events" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="events" className="ml-2 text-sm text-gray-700">Events</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="testimonials" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="testimonials" className="ml-2 text-sm text-gray-700">Testimonials</label>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Date Added</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="radio" id="all-time" name="date-filter" className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="all-time" className="ml-2 text-sm text-gray-700">All Time</label>
              </div>
              <div className="flex items-center">
                <input type="radio" id="last-week" name="date-filter" className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500" />
                <label htmlFor="last-week" className="ml-2 text-sm text-gray-700">Last Week</label>
              </div>
              <div className="flex items-center">
                <input type="radio" id="last-month" name="date-filter" className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500" />
                <label htmlFor="last-month" className="ml-2 text-sm text-gray-700">Last Month</label>
              </div>
              <div className="flex items-center">
                <input type="radio" id="last-3-months" name="date-filter" className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500" />
                <label htmlFor="last-3-months" className="ml-2 text-sm text-gray-700">Last 3 Months</label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-9">
          <div className="rounded-lg border bg-white shadow-sm">
            <div className="p-4 border-b">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-gray-400">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                </div>
                <input
                  type="search"
                  className="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Search content..."
                />
              </div>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="rounded-lg border bg-white overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <div className="aspect-square bg-gray-100 relative">
                      {i % 4 === 0 ? (
                        <div className="absolute top-2 right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded">Video</div>
                      ) : null}
                      <div className="h-full w-full flex items-center justify-center text-gray-400">
                        <span>Image {i + 1}</span>
                      </div>
                    </div>
                    <div className="p-3">
                      <h4 className="font-medium text-sm truncate">Content Item #{i + 1}</h4>
                      <p className="text-xs text-gray-500 mt-1">Added on {i % 3 === 0 ? "Apr 1, 2025" : i % 2 === 0 ? "Mar 28, 2025" : "Mar 15, 2025"}</p>
                      <div className="flex space-x-1 mt-2">
                        <span className="inline-flex items-center rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-800">
                          {i % 5 === 0 ? "Marketing" : i % 4 === 0 ? "Product" : i % 3 === 0 ? "Branding" : i % 2 === 0 ? "Events" : "Testimonials"}
                        </span>
                      </div>
                      <div className="flex space-x-1 mt-2">
                        <Button variant="outline" size="sm" className="w-full">Use</Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="p-4 border-t">
              <div className="flex items-center justify-between">
                <Button variant="outline" size="sm">Previous</Button>
                <div className="flex items-center space-x-1">
                  <span className="px-2 py-1 text-sm font-medium rounded-md bg-blue-100 text-blue-700">1</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">2</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">3</span>
                  <span className="px-2 py-1 text-sm">...</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">8</span>
                </div>
                <Button variant="outline" size="sm">Next</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
