import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import Settings from '@/app/(dashboard)/settings/page';
import { useUser } from '@/lib/user-context';

// Mock the custom hook
vi.mock('@/lib/user-context', () => ({
  useUser: vi.fn()
}));

describe('Settings Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders settings with connected accounts correctly', () => {
    // Mock the hook to return social accounts
    useUser.mockReturnValue({
      socialAccounts: [
        {
          id: '1',
          platform: 'twitter',
          username: 'acmeinc',
          profileUrl: 'https://twitter.com/acmeinc',
          profileImage: 'https://randomuser.me/api/portraits/men/1.jpg',
          connected: true,
        },
        {
          id: '2',
          platform: 'instagram',
          username: 'acmeinc',
          profileUrl: 'https://instagram.com/acmeinc',
          profileImage: 'https://randomuser.me/api/portraits/men/1.jpg',
          connected: true,
        }
      ],
      addSocialAccount: vi.fn(),
      removeSocialAccount: vi.fn(),
      updateSocialAccount: vi.fn(),
    });

    render(<Settings />);
    
    // Check for main settings elements
    expect(screen.getByText('Settings')).toBeInTheDocument();
    expect(screen.getByText('Account Settings')).toBeInTheDocument();
    expect(screen.getByText('Connected Accounts')).toBeInTheDocument();
    
    // Check for connected accounts
    expect(screen.getByText('Twitter')).toBeInTheDocument();
    expect(screen.getByText('Instagram')).toBeInTheDocument();
    expect(screen.getByText('@acmeinc')).toBeInTheDocument();
  });

  it('renders settings with no connected accounts correctly', () => {
    // Mock the hook to return empty social accounts
    useUser.mockReturnValue({
      socialAccounts: [],
      addSocialAccount: vi.fn(),
      removeSocialAccount: vi.fn(),
      updateSocialAccount: vi.fn(),
    });

    render(<Settings />);
    
    // Check for main settings elements
    expect(screen.getByText('Settings')).toBeInTheDocument();
    expect(screen.getByText('Account Settings')).toBeInTheDocument();
    expect(screen.getByText('Connected Accounts')).toBeInTheDocument();
    
    // Check for no connected accounts message
    expect(screen.getByText('No social media accounts connected')).toBeInTheDocument();
  });
});
