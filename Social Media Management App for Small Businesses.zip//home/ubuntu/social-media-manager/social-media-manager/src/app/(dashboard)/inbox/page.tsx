import React from "react";
import { Button } from "@/components/ui/button";

export default function Inbox() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Smart Inbox</h1>
        <div className="flex space-x-2">
          <Button variant="outline">Filter</Button>
          <Button variant="outline">Sort</Button>
          <Button>Mark All as Read</Button>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-12">
        <div className="md:col-span-3 space-y-4">
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Platforms</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="twitter" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="twitter" className="ml-2 text-sm text-gray-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-blue-500">
                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                  </svg>
                  Twitter
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="instagram" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="instagram" className="ml-2 text-sm text-gray-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-pink-500">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                  </svg>
                  Instagram
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="facebook" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="facebook" className="ml-2 text-sm text-gray-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-blue-700">
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                  </svg>
                  Facebook
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="linkedin" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="linkedin" className="ml-2 text-sm text-gray-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1 text-blue-800">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                    <rect x="2" y="9" width="4" height="12" />
                    <circle cx="4" cy="4" r="2" />
                  </svg>
                  LinkedIn
                </label>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Message Type</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="comments" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="comments" className="ml-2 text-sm text-gray-700">Comments</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="mentions" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="mentions" className="ml-2 text-sm text-gray-700">Mentions</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="direct" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="direct" className="ml-2 text-sm text-gray-700">Direct Messages</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="reviews" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="reviews" className="ml-2 text-sm text-gray-700">Reviews</label>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-medium mb-2">Status</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="unread" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="unread" className="ml-2 text-sm text-gray-700">Unread</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="read" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                <label htmlFor="read" className="ml-2 text-sm text-gray-700">Read</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="flagged" className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <label htmlFor="flagged" className="ml-2 text-sm text-gray-700">Flagged</label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-9">
          <div className="rounded-lg border bg-white shadow-sm">
            <div className="p-4 border-b">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-gray-400">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                </div>
                <input
                  type="search"
                  className="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Search messages..."
                />
              </div>
            </div>
            
            <div className="divide-y">
              {[1, 2, 3, 4, 5, 6, 7].map((i) => (
                <div key={i} className={`p-4 hover:bg-gray-50 cursor-pointer ${i === 2 ? 'bg-blue-50' : ''}`}>
                  <div className="flex items-start space-x-4">
                    <span className="relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full">
                      <img
                        className="aspect-square h-full w-full"
                        src={`https://randomuser.me/api/portraits/${i % 2 === 0 ? 'women' : 'men'}/${i + 10}.jpg`}
                        alt="Avatar"
                      />
                    </span>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <p className="text-sm font-medium">Jane Smith</p>
                          <span className="flex items-center">
                            {i % 4 === 0 ? (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 text-blue-500">
                                <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
                              </svg>
                            ) : i % 3 === 0 ? (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 text-pink-500">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                              </svg>
                            ) : i % 2 === 0 ? (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 text-blue-700">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                              </svg>
                            ) : (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 text-blue-800">
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                                <rect x="2" y="9" width="4" height="12" />
                                <circle cx="4" cy="4" r="2" />
                              </svg>
                            )}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          {i === 1 || i === 3 || i === 5 ? (
                            <span className="inline-flex items-center rounded-full bg-blue-100 px-2 py-1 text-xs font-medium text-blue-800">
                              New
                            </span>
                          ) : null}
                          <p className="text-xs text-gray-500">
                            {i === 1 ? "Just now" : i === 2 ? "5 min ago" : i === 3 ? "1 hour ago" : i === 4 ? "3 hours ago" : i === 5 ? "Yesterday" : i === 6 ? "2 days ago" : "1 week ago"}
                          </p>
                        </div>
                      </div>
                      <p className="text-sm text-gray-700">
                        {i % 4 === 0 
                          ? "Hey there! I love your recent post about digital marketing strategies. Could you share more insights?" 
                          : i % 3 === 0 
                            ? "Your product looks amazing! I'd like to know more about pricing options."
                            : i % 2 === 0
                              ? "Thanks for the quick response! That's exactly what I was looking for."
                              : "I've been following your content for a while now and I'm really impressed with your work!"
                        }
                      </p>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Reply</Button>
                        <Button variant="outline" size="sm">Mark as Read</Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t">
              <div className="flex items-center justify-between">
                <Button variant="outline" size="sm">Previous</Button>
                <div className="flex items-center space-x-1">
                  <span className="px-2 py-1 text-sm font-medium rounded-md bg-blue-100 text-blue-700">1</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">2</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">3</span>
                  <span className="px-2 py-1 text-sm">...</span>
                  <span className="px-2 py-1 text-sm font-medium rounded-md hover:bg-gray-100">8</span>
                </div>
                <Button variant="outline" size="sm">Next</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
