import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import Dashboard from '@/app/(dashboard)/dashboard/page';
import { useDashboardData } from '@/hooks/use-dashboard-data';

// Mock the custom hook
vi.mock('@/hooks/use-dashboard-data', () => ({
  useDashboardData: vi.fn()
}));

describe('Dashboard Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders loading state correctly', () => {
    // Mock the hook to return loading state
    useDashboardData.mockReturnValue({
      loading: true,
      error: null,
      accountStats: {},
      recentActivity: [],
      upcomingPosts: []
    });

    render(<Dashboard />);
    
    expect(screen.getByText('Loading dashboard data...')).toBeInTheDocument();
  });

  it('renders error state correctly', () => {
    // Mock the hook to return error state
    useDashboardData.mockReturnValue({
      loading: false,
      error: 'Failed to load dashboard data',
      accountStats: {},
      recentActivity: [],
      upcomingPosts: []
    });

    render(<Dashboard />);
    
    expect(screen.getByText('Error Loading Data')).toBeInTheDocument();
    expect(screen.getByText('Failed to load dashboard data')).toBeInTheDocument();
  });

  it('renders dashboard content correctly', () => {
    // Mock the hook to return successful data
    useDashboardData.mockReturnValue({
      loading: false,
      error: null,
      accountStats: {
        followers: 12345,
        engagement: 3.2,
        scheduledPosts: 24,
        unreadMessages: 18
      },
      recentActivity: [
        {
          id: '1',
          type: 'comment',
          user: {
            name: 'Jane Smith',
            image: 'https://randomuser.me/api/portraits/women/12.jpg'
          },
          content: 'User commented on your post',
          time: 'Just now'
        }
      ],
      upcomingPosts: [
        {
          id: '1',
          title: 'New Product Announcement',
          platform: 'twitter',
          scheduledTime: 'Today, 3:00 PM'
        }
      ]
    });

    render(<Dashboard />);
    
    // Check for main dashboard elements
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    expect(screen.getByText('Total Followers')).toBeInTheDocument();
    expect(screen.getByText('12,345')).toBeInTheDocument();
    expect(screen.getByText('Engagement Rate')).toBeInTheDocument();
    expect(screen.getByText('3.2%')).toBeInTheDocument();
    expect(screen.getByText('Scheduled Posts')).toBeInTheDocument();
    expect(screen.getByText('24')).toBeInTheDocument();
    expect(screen.getByText('Unread Messages')).toBeInTheDocument();
    expect(screen.getByText('18')).toBeInTheDocument();
    
    // Check for activity and posts
    expect(screen.getByText('Recent Activity')).toBeInTheDocument();
    expect(screen.getByText('User commented on your post')).toBeInTheDocument();
    expect(screen.getByText('Upcoming Posts')).toBeInTheDocument();
    expect(screen.getByText('New Product Announcement')).toBeInTheDocument();
  });
});
