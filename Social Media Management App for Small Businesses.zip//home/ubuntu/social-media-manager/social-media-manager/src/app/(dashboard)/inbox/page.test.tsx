import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { useInbox } from '@/lib/inbox-context';
import Inbox from '@/app/(dashboard)/inbox/page';

// Mock the custom hook
vi.mock('@/lib/inbox-context', () => ({
  useInbox: vi.fn()
}));

describe('Inbox Component', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders inbox with messages correctly', () => {
    // Mock the hook to return messages
    useInbox.mockReturnValue({
      messages: [
        {
          id: '1',
          platform: 'twitter',
          type: 'mention',
          content: 'Hey @acmeinc, love your products!',
          sender: {
            id: 'user1',
            name: 'Jane Smith',
            username: 'janesmith',
            profileImage: 'https://randomuser.me/api/portraits/women/12.jpg',
          },
          timestamp: new Date('2025-04-01T04:30:00'),
          isRead: false,
          isFlagged: false,
        },
        {
          id: '2',
          platform: 'instagram',
          type: 'comment',
          content: 'Your latest post is amazing!',
          sender: {
            id: 'user2',
            name: 'Robert Johnson',
            username: 'robertj',
            profileImage: 'https://randomuser.me/api/portraits/men/15.jpg',
          },
          timestamp: new Date('2025-03-31T18:45:00'),
          isRead: false,
          isFlagged: true,
        }
      ],
      unreadCount: 2,
      markAsRead: vi.fn(),
      markAllAsRead: vi.fn(),
      toggleFlag: vi.fn(),
      deleteMessage: vi.fn(),
      filterMessages: vi.fn().mockReturnValue([]),
    });

    render(<Inbox />);
    
    // Check for main inbox elements
    expect(screen.getByText('Smart Inbox')).toBeInTheDocument();
    expect(screen.getByText('Jane Smith')).toBeInTheDocument();
    expect(screen.getByText('Robert Johnson')).toBeInTheDocument();
    expect(screen.getByText('Hey @acmeinc, love your products!')).toBeInTheDocument();
    expect(screen.getByText('Your latest post is amazing!')).toBeInTheDocument();
    
    // Check for filter options
    expect(screen.getByText('Platforms')).toBeInTheDocument();
    expect(screen.getByText('Twitter')).toBeInTheDocument();
    expect(screen.getByText('Instagram')).toBeInTheDocument();
    expect(screen.getByText('Message Type')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(screen.getByText('Mentions')).toBeInTheDocument();
  });

  it('renders empty inbox state correctly', () => {
    // Mock the hook to return empty messages
    useInbox.mockReturnValue({
      messages: [],
      unreadCount: 0,
      markAsRead: vi.fn(),
      markAllAsRead: vi.fn(),
      toggleFlag: vi.fn(),
      deleteMessage: vi.fn(),
      filterMessages: vi.fn().mockReturnValue([]),
    });

    render(<Inbox />);
    
    // Check for main inbox elements
    expect(screen.getByText('Smart Inbox')).toBeInTheDocument();
    expect(screen.getByText('Platforms')).toBeInTheDocument();
    
    // No messages should be displayed
    expect(screen.queryByText('Jane Smith')).not.toBeInTheDocument();
    expect(screen.queryByText('Robert Johnson')).not.toBeInTheDocument();
  });
});
