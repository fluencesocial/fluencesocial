"use client";

import { useEffect, useState } from 'react';
import { useAnalytics } from '@/lib/analytics-context';
import { fetchTwitterProfile, searchTwitter, fetchLinkedInProfile, searchLinkedIn } from '@/lib/social-api';

export function useAnalyticsData() {
  const { data: contextData, loading: contextLoading, timeRange } = useAnalytics();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    const fetchAnalyticsData = async () => {
      setLoading(true);
      setError(null);
      
      try {
        // Start with context data as a base
        let analyticsData = { ...contextData };
        
        // Fetch Twitter data for analytics enhancement
        try {
          // Get profile data for a business account to analyze
          const twitterProfile = await fetchTwitterProfile('MrBeast');
          
          if (twitterProfile && twitterProfile.result && twitterProfile.result.data && 
              twitterProfile.result.data.user && twitterProfile.result.data.user.result) {
            const userData = twitterProfile.result.data.user.result;
            
            // Update followers data with real Twitter data if available
            if (userData.legacy) {
              analyticsData = {
                ...analyticsData,
                followers: {
                  ...analyticsData.followers,
                  byPlatform: analyticsData.followers.byPlatform.map((platform: any) => {
                    if (platform.platform === 'twitter') {
                      return {
                        ...platform,
                        count: userData.legacy.followers_count || platform.count
                      };
                    }
                    return platform;
                  })
                }
              };
            }
          }
          
          // Search for brand mentions to analyze engagement
          const searchResults = await searchTwitter('social media management', 10);
          
          // Process search results to enhance analytics data
          // This would be more sophisticated in a real application
          if (searchResults && searchResults.result && searchResults.result.timeline) {
            // Update engagement data based on search results
            // This is simplified for demo purposes
          }
        } catch (twitterError) {
          console.error('Error fetching Twitter analytics data:', twitterError);
          // Continue with other data sources even if Twitter fails
        }
        
        // Fetch LinkedIn data for analytics enhancement
        try {
          const linkedInProfile = await fetchLinkedInProfile('adamselipsky');
          
          if (linkedInProfile && linkedInProfile.data) {
            // Update analytics data with LinkedIn information
            // This is simplified for demo purposes
          }
          
          const linkedInSearch = await searchLinkedIn('social media marketing');
          
          if (linkedInSearch && linkedInSearch.data) {
            // Process LinkedIn search results to enhance analytics
            // This is simplified for demo purposes
          }
        } catch (linkedInError) {
          console.error('Error fetching LinkedIn analytics data:', linkedInError);
          // Continue even if LinkedIn fails
        }
        
        // Set the enhanced analytics data
        setData(analyticsData);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching analytics data:', err);
        setError('Failed to load analytics data');
        setLoading(false);
      }
    };
    
    if (contextData) {
      fetchAnalyticsData();
    }
  }, [contextData, timeRange]);
  
  return {
    loading: loading || contextLoading,
    error,
    data,
    timeRange
  };
}
