"use client";

import { useEffect, useState } from 'react';
import { useAnalytics } from '@/lib/analytics-context';
import { useUser } from '@/lib/user-context';
import { fetchTwitterProfile, fetchTwitterTweets } from '@/lib/social-api';

export function useDashboardData() {
  const { data: analyticsData, loading: analyticsLoading } = useAnalytics();
  const { socialAccounts } = useUser();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [upcomingPosts, setUpcomingPosts] = useState<any[]>([]);
  const [accountStats, setAccountStats] = useState<any>({
    followers: 0,
    engagement: 0,
    scheduledPosts: 0,
    unreadMessages: 0
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      setError(null);
      
      try {
        // Get Twitter account if available
        const twitterAccount = socialAccounts.find(account => account.platform === 'twitter');
        
        if (twitterAccount) {
          // Fetch Twitter profile data
          const profileData = await fetchTwitterProfile(twitterAccount.username);
          
          // Update account stats with real data if available
          if (profileData && profileData.result && profileData.result.data && profileData.result.data.user && profileData.result.data.user.result) {
            const userData = profileData.result.data.user.result;
            if (userData.legacy) {
              setAccountStats(prev => ({
                ...prev,
                followers: userData.legacy.followers_count || prev.followers
              }));
            }
          }
          
          // Fetch recent tweets
          if (profileData && profileData.result && profileData.result.data && profileData.result.data.user && profileData.result.data.user.result) {
            const userId = profileData.result.data.user.result.rest_id;
            const tweetsData = await fetchTwitterTweets(userId);
            
            // Process tweets for recent activity
            if (tweetsData && tweetsData.result && tweetsData.result.timeline) {
              // Process tweets data to create activity items
              // This is simplified for demo purposes
              const activities = [
                {
                  id: '1',
                  type: 'comment',
                  user: {
                    name: 'Jane Smith',
                    image: 'https://randomuser.me/api/portraits/women/12.jpg'
                  },
                  content: 'User commented on your post',
                  time: 'Just now'
                },
                {
                  id: '2',
                  type: 'like',
                  user: {
                    name: 'Robert Johnson',
                    image: 'https://randomuser.me/api/portraits/men/22.jpg'
                  },
                  content: 'User liked your tweet',
                  time: '2 hours ago'
                },
                {
                  id: '3',
                  type: 'retweet',
                  user: {
                    name: 'Emily Davis',
                    image: 'https://randomuser.me/api/portraits/women/22.jpg'
                  },
                  content: 'User retweeted your post',
                  time: 'Yesterday'
                },
                {
                  id: '4',
                  type: 'mention',
                  user: {
                    name: 'Michael Wilson',
                    image: 'https://randomuser.me/api/portraits/men/32.jpg'
                  },
                  content: 'User mentioned you in a tweet',
                  time: '2 days ago'
                },
                {
                  id: '5',
                  type: 'follow',
                  user: {
                    name: 'Sarah Brown',
                    image: 'https://randomuser.me/api/portraits/women/33.jpg'
                  },
                  content: 'User started following you',
                  time: '1 week ago'
                }
              ];
              
              setRecentActivity(activities);
            }
          }
        }
        
        // Set upcoming posts (this would come from the content library in a real app)
        const mockUpcomingPosts = [
          {
            id: '1',
            title: 'New Product Announcement',
            platform: 'twitter',
            scheduledTime: 'Today, 3:00 PM'
          },
          {
            id: '2',
            title: 'Customer Testimonial',
            platform: 'instagram',
            scheduledTime: 'Tomorrow, 10:00 AM'
          },
          {
            id: '3',
            title: 'Industry News Share',
            platform: 'linkedin',
            scheduledTime: 'Apr 3, 2:30 PM'
          },
          {
            id: '4',
            title: 'Weekly Tips and Tricks',
            platform: 'facebook',
            scheduledTime: 'Apr 5, 9:00 AM'
          },
          {
            id: '5',
            title: 'Behind the Scenes',
            platform: 'instagram',
            scheduledTime: 'Apr 7, 4:15 PM'
          }
        ];
        
        setUpcomingPosts(mockUpcomingPosts);
        
        // Set account stats if not already set from API data
        if (analyticsData) {
          setAccountStats(prev => ({
            ...prev,
            followers: prev.followers || analyticsData.followers.total,
            engagement: analyticsData.engagement.rate,
            scheduledPosts: mockUpcomingPosts.length,
            unreadMessages: 18 // This would come from the inbox context in a real app
          }));
        }
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data');
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [socialAccounts, analyticsData]);
  
  return {
    loading: loading || analyticsLoading,
    error,
    accountStats,
    recentActivity,
    upcomingPosts
  };
}
