import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { SessionProvider } from 'next-auth/react';
import { Providers } from '@/components/providers';

// Mock the next-auth session provider
vi.mock('next-auth/react', () => ({
  SessionProvider: ({ children }) => <div>{children}</div>,
  useSession: vi.fn().mockReturnValue({
    data: { user: { name: 'Test User', email: 'test@example.com' } },
    status: 'authenticated'
  })
}));

// Mock the context providers
vi.mock('@/lib/user-context', () => ({
  UserProvider: ({ children }) => <div data-testid="user-provider">{children}</div>,
  useUser: vi.fn()
}));

vi.mock('@/lib/content-library-context', () => ({
  ContentLibraryProvider: ({ children }) => <div data-testid="content-library-provider">{children}</div>,
  useContentLibrary: vi.fn()
}));

vi.mock('@/lib/inbox-context', () => ({
  InboxProvider: ({ children }) => <div data-testid="inbox-provider">{children}</div>,
  useInbox: vi.fn()
}));

vi.mock('@/lib/analytics-context', () => ({
  AnalyticsProvider: ({ children }) => <div data-testid="analytics-provider">{children}</div>,
  useAnalytics: vi.fn()
}));

describe('Providers Component', () => {
  it('renders all providers correctly', () => {
    render(<Providers>Test Content</Providers>);
    
    // Check that all providers are rendered
    expect(screen.getByTestId('user-provider')).toBeInTheDocument();
    expect(screen.getByTestId('content-library-provider')).toBeInTheDocument();
    expect(screen.getByTestId('inbox-provider')).toBeInTheDocument();
    expect(screen.getByTestId('analytics-provider')).toBeInTheDocument();
    
    // Check that children are rendered
    expect(screen.getByText('Test Content')).toBeInTheDocument();
  });
});
