"use client";

import { SessionProvider } from 'next-auth/react';
import { UserProvider } from '@/lib/user-context';
import { ContentLibraryProvider } from '@/lib/content-library-context';
import { InboxProvider } from '@/lib/inbox-context';
import { AnalyticsProvider } from '@/lib/analytics-context';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <UserProvider>
        <ContentLibraryProvider>
          <InboxProvider>
            <AnalyticsProvider>
              {children}
            </AnalyticsProvider>
          </InboxProvider>
        </ContentLibraryProvider>
      </UserProvider>
    </SessionProvider>
  );
}
