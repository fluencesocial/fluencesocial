# Social Media Manager - Deployment Guide

This document provides instructions for deploying the Social Media Manager application.

## Prerequisites

- Node.js 18.x or higher
- npm or pnpm package manager
- A Cloudflare account (for Next.js deployment)

## Local Development

1. Clone the repository
2. Install dependencies:
   ```
   cd social-media-manager
   pnpm install
   ```
3. Run the development server:
   ```
   pnpm dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Building for Production

To build the application for production:

```
pnpm build
```

This will create an optimized production build in the `.next` directory.

## Deployment Options

### Option 1: Cloudflare Pages (Recommended)

1. Set up a Cloudflare Pages project
2. Connect your repository
3. Configure the build settings:
   - Build command: `pnpm build`
   - Build output directory: `.next`
4. Deploy the application

### Option 2: Vercel

1. Install the Vercel CLI:
   ```
   npm install -g vercel
   ```
2. Deploy the application:
   ```
   vercel
   ```

### Option 3: Static Export

For static hosting environments:

1. Add the following to your `next.config.js`:
   ```js
   module.exports = {
     output: 'export',
   }
   ```
2. Build the application:
   ```
   pnpm build
   ```
3. The static files will be in the `out` directory

## Environment Variables

Create a `.env.local` file with the following variables:

```
NEXTAUTH_URL=https://your-domain.com
NEXTAUTH_SECRET=your-secret-key
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
```

## Post-Deployment Verification

After deployment, verify the following:

1. Authentication works correctly
2. Social media connections can be established
3. Dashboard displays data correctly
4. Analytics visualizations render properly
5. Content scheduling functions as expected

## Troubleshooting

If you encounter issues during deployment:

1. Check the build logs for errors
2. Verify environment variables are set correctly
3. Ensure API endpoints are accessible
4. Check browser console for client-side errors

## Support

For additional support, contact the development team.
